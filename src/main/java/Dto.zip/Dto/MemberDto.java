package Dto;

import java.sql.Timestamp;

public class MemberDto {

		private String Mem_no;
		private String Mem_id;
		private String Mem_pass;
		private String Mem_name;
		private String Mem_gender;
		private String Mem_birth;
		private String Mem_ph;
		private String Mem_email;
		private Timestamp Mem_regdate;
		private String Mem_addr;
		
		public String getMem_no() {
			return Mem_no;
		}
		public void setMem_no(String mem_no) {
			Mem_no = mem_no;
		}
		public String getMem_id() {
			return Mem_id;
		}
		public void setMem_id(String mem_id) {
			Mem_id = mem_id;
		}
		public String getMem_pass() {
			return Mem_pass;
		}
		public void setMem_pass(String mem_pass) {
			Mem_pass = mem_pass;
		}
		public String getMem_name() {
			return Mem_name;
		}
		public void setMem_name(String mem_name) {
			Mem_name = mem_name;
		}
		public String getMem_gender() {
			return Mem_gender;
		}
		public void setMem_gender(String mem_gender) {
			Mem_gender = mem_gender;
		}
		public String getMem_birth() {
			return Mem_birth;
		}
		public void setMem_birth(String mem_birth) {
			Mem_birth = mem_birth;
		}
		public String getMem_ph() {
			return Mem_ph;
		}
		public void setMem_ph(String mem_ph) {
			Mem_ph = mem_ph;
		}
		public String getMem_email() {
			return Mem_email;
		}
		public void setMem_email(String mem_email) {
			Mem_email = mem_email;
		}
		public Timestamp getMem_regdate() {
			return Mem_regdate;
		}
		public void setMem_regdate(Timestamp mem_regdate) {
			Mem_regdate = mem_regdate;
		}
		public String getMem_addr() {
			return Mem_addr;
		}
		public void setMem_addr(String mem_addr) {
			Mem_addr = mem_addr;
		}
		
		
		
		
}
