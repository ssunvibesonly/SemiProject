package Dto;

public class MovieDto {
	
	private String mv_no;
	private String mv_title;
	private String mv_poster;
	private String mv_director;
	private String mv_st;
	private String mv_trailer;
	private String mv_opendate;
	private String mv_info;
	private String mv_regdate;
	private String mv_genre;
	private String mv_name;
	private int mv_adult;
	private int mv_teen;
	private int mv_child;
	
	public String getMv_no() {
		return mv_no;
	}
	public void setMv_no(String mv_no) {
		this.mv_no = mv_no;
	}
	public String getMv_title() {
		return mv_title;
	}
	public void setMv_title(String mv_title) {
		this.mv_title = mv_title;
	}
	public String getMv_poster() {
		return mv_poster;
	}
	public void setMv_poster(String mv_poster) {
		this.mv_poster = mv_poster;
	}
	public String getMv_director() {
		return mv_director;
	}
	public void setMv_director(String mv_director) {
		this.mv_director = mv_director;
	}
	public String getMv_st() {
		return mv_st;
	}
	public void setMv_st(String mv_st) {
		this.mv_st = mv_st;
	}
	public String getMv_trailer() {
		return mv_trailer;
	}
	public void setMv_trailer(String mv_trailer) {
		this.mv_trailer = mv_trailer;
	}
	public String getMv_opendate() {
		return mv_opendate;
	}
	public void setMv_opendate(String mv_opendate) {
		this.mv_opendate = mv_opendate;
	}
	public String getMv_info() {
		return mv_info;
	}
	public void setMv_info(String mv_info) {
		this.mv_info = mv_info;
	}
	public String getMv_regdate() {
		return mv_regdate;
	}
	public void setMv_regdate(String mv_regdate) {
		this.mv_regdate = mv_regdate;
	}
	public String getMv_genre() {
		return mv_genre;
	}
	public void setMv_genre(String mv_genre) {
		this.mv_genre = mv_genre;
	}
	public String getMv_name() {
		return mv_name;
	}
	public void setMv_name(String mv_name) {
		this.mv_name = mv_name;
	}
	public int getMv_adult() {
		return mv_adult;
	}
	public void setMv_adult(int mv_adult) {
		this.mv_adult = mv_adult;
	}
	public int getMv_teen() {
		return mv_teen;
	}
	public void setMv_teen(int mv_teen) {
		this.mv_teen = mv_teen;
	}
	public int getMv_child() {
		return mv_child;
	}
	public void setMv_child(int mv_child) {
		this.mv_child = mv_child;
	}
	
	

}
